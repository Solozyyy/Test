package btapjava;

import java.util.Scanner;
import static java.lang.Math.*;
import java.math.BigInteger;
import java.util.*;

public class Btapjava {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int tc = Integer.parseInt(sc.nextLine());
        ArrayList<hs> a = new ArrayList<>();
        while(tc-->0){
            String id = sc.nextLine();
            String ten = sc.nextLine();
            double dt = Double.parseDouble(sc.nextLine());
            double dl = Double.parseDouble(sc.nextLine());
            double dh = Double.parseDouble(sc.nextLine());
            hs push = new hs(id, ten, dt, dl ,dh);
            a.add(push);
        }
        Comparator<hs> cmp = new Comparator<hs>(){
            public int compare(hs h1, hs h2){
                if(h1.getDiemSoSanh() - h2.getDiemSoSanh() < 0) return 1;
                else if(h1.getDiemSoSanh() - h2.getDiemSoSanh() == 0){
                    return h1.getID().compareTo(h2.getID());
                }
                else return -1;
            }
        };
        Collections.sort(a, cmp);
        for(hs x : a) {
            System.out.println(x.toString());
        }
    }
}
